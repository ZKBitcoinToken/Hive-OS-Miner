#!/bin/bash

# Prompt user to enter the private key
read -sp "Enter your private key: " private_key
echo

# Check if private key is not empty
if [[ -z "$private_key" ]]; then
  echo "Private key cannot be empty."
  exit 1
fi

padded_key=$(echo "$private_key" | awk '{printf "%064s", substr($0, 3)}' | sed 's/ /0/g')
echo "PADDED KEY: $padded_key"

private_key2="0x$padded_key"
echo "Private Key saved as: $private_key2"
# Define the file to store the private key
private_key_file="/etc/private_key.conf"
backup_file="${private_key_file}.bak"

# Backup existing private_key.conf if it exists and append the new key to the backup
if [[ -f $private_key_file ]]; then
  if [[ -f $backup_file ]]; then
    echo "$private_key2" >> $backup_file
  else
    cp $private_key_file $backup_file
    echo "$private_key2" >> $backup_file
  fi
  echo "A backup of the existing private_key.conf has been created or updated as $backup_file."
fi

# Write the private key to the file
echo "$private_key2" > $private_key_file

# Inform the user
echo "Private key has been added to $private_key2 and appended to $backup_file."

